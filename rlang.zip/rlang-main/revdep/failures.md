# aggregateBioVar

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/aggregateBioVar
* Number of recursive dependencies: 118

Run `revdepcheck::cloud_details(, "aggregateBioVar")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# airpart

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/airpart
* Number of recursive dependencies: 174

Run `revdepcheck::cloud_details(, "airpart")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# alevinQC

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/alevinQC
* Number of recursive dependencies: 98

Run `revdepcheck::cloud_details(, "alevinQC")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# AlpsNMR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/AlpsNMR
* Number of recursive dependencies: 175

Run `revdepcheck::cloud_details(, "AlpsNMR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# AnVIL

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/AnVIL
* Number of recursive dependencies: 118

Run `revdepcheck::cloud_details(, "AnVIL")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# APL

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/APL
* Number of recursive dependencies: 247

Run `revdepcheck::cloud_details(, "APL")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ArrayExpress

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ArrayExpress
* Number of recursive dependencies: 59

Run `revdepcheck::cloud_details(, "ArrayExpress")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# autonomics

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/autonomics
* Number of recursive dependencies: 203

Run `revdepcheck::cloud_details(, "autonomics")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# bandle

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/bandle
* Number of recursive dependencies: 246

Run `revdepcheck::cloud_details(, "bandle")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# barcodetrackR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/barcodetrackR
* Number of recursive dependencies: 117

Run `revdepcheck::cloud_details(, "barcodetrackR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# bayesdfa

<details>

* Version: 1.3.1
* GitHub: https://github.com/fate-ewi/bayesdfa
* Source code: https://github.com/cran/bayesdfa
* Date/Publication: 2023-10-11 15:10:02 UTC
* Number of recursive dependencies: 86

Run `revdepcheck::cloud_details(, "bayesdfa")` for more info

</details>

## In both

*   checking whether package ‘bayesdfa’ can be installed ... ERROR
    ```
    Installation failed.
    See ‘/tmp/workdir/bayesdfa/new/bayesdfa.Rcheck/00install.out’ for details.
    ```

## Installation

### Devel

```
* installing *source* package ‘bayesdfa’ ...
** package ‘bayesdfa’ successfully unpacked and MD5 sums checked
** using staged installation
** libs
using C++ compiler: ‘g++ (Ubuntu 9.4.0-1ubuntu1~20.04.2) 9.4.0’
using C++17


g++ -std=gnu++17 -I"/opt/R/4.3.1/lib/R/include" -DNDEBUG -I"../inst/include" -I"/opt/R/4.3.1/lib/R/site-library/StanHeaders/include/src" -DBOOST_DISABLE_ASSERTS -DEIGEN_NO_DEBUG -DBOOST_MATH_OVERFLOW_ERROR_POLICY=errno_on_error -DUSE_STANC3 -D_HAS_AUTO_PTR_ETC=0 -I'/opt/R/4.3.1/lib/R/site-library/BH/include' -I'/opt/R/4.3.1/lib/R/site-library/Rcpp/include' -I'/opt/R/4.3.1/lib/R/site-library/RcppEigen/include' -I'/opt/R/4.3.1/lib/R/site-library/RcppParallel/include' -I'/opt/R/4.3.1/lib/R/site-library/rstan/include' -I'/opt/R/4.3.1/lib/R/site-library/StanHeaders/include' -I/usr/local/include    -I'/opt/R/4.3.1/lib/R/site-library/RcppParallel/include' -D_REENTRANT -DSTAN_THREADS   -fpic  -g -O2  -c RcppExports.cpp -o RcppExports.o
In file included from /opt/R/4.3.1/lib/R/site-library/RcppEigen/include/Eigen/Core:397,
...
/opt/R/4.3.1/lib/R/site-library/RcppEigen/include/Eigen/src/Core/ProductEvaluators.h:35:90:   required from ‘Eigen::internal::evaluator<Eigen::Product<Lhs, Rhs, Option> >::evaluator(const XprType&) [with Lhs = Eigen::Product<Eigen::CwiseBinaryOp<Eigen::internal::scalar_product_op<double, double>, const Eigen::CwiseNullaryOp<Eigen::internal::scalar_constant_op<double>, const Eigen::Matrix<double, 1, -1> >, const Eigen::Transpose<Eigen::Matrix<double, -1, 1> > >, Eigen::Matrix<double, -1, -1>, 0>; Rhs = Eigen::Matrix<double, -1, 1>; int Options = 0; Eigen::internal::evaluator<Eigen::Product<Lhs, Rhs, Option> >::XprType = Eigen::Product<Eigen::Product<Eigen::CwiseBinaryOp<Eigen::internal::scalar_product_op<double, double>, const Eigen::CwiseNullaryOp<Eigen::internal::scalar_constant_op<double>, const Eigen::Matrix<double, 1, -1> >, const Eigen::Transpose<Eigen::Matrix<double, -1, 1> > >, Eigen::Matrix<double, -1, -1>, 0>, Eigen::Matrix<double, -1, 1>, 0>]’
/opt/R/4.3.1/lib/R/site-library/RcppEigen/include/Eigen/src/Core/Product.h:132:22:   required from ‘Eigen::internal::dense_product_base<Lhs, Rhs, Option, 6>::operator const Scalar() const [with Lhs = Eigen::Product<Eigen::CwiseBinaryOp<Eigen::internal::scalar_product_op<double, double>, const Eigen::CwiseNullaryOp<Eigen::internal::scalar_constant_op<double>, const Eigen::Matrix<double, 1, -1> >, const Eigen::Transpose<Eigen::Matrix<double, -1, 1> > >, Eigen::Matrix<double, -1, -1>, 0>; Rhs = Eigen::Matrix<double, -1, 1>; int Option = 0; Eigen::internal::dense_product_base<Lhs, Rhs, Option, 6>::Scalar = double]’
/opt/R/4.3.1/lib/R/site-library/StanHeaders/include/src/stan/mcmc/hmc/hamiltonians/dense_e_metric.hpp:22:56:   required from ‘double stan::mcmc::dense_e_metric<Model, BaseRNG>::T(stan::mcmc::dense_e_point&) [with Model = model_dfa_namespace::model_dfa; BaseRNG = boost::random::additive_combine_engine<boost::random::linear_congruential_engine<unsigned int, 40014, 0, 2147483563>, boost::random::linear_congruential_engine<unsigned int, 40692, 0, 2147483399> >]’
/opt/R/4.3.1/lib/R/site-library/StanHeaders/include/src/stan/mcmc/hmc/hamiltonians/dense_e_metric.hpp:21:10:   required from here
/opt/R/4.3.1/lib/R/site-library/RcppEigen/include/Eigen/src/Core/DenseCoeffsBase.h:55:30: warning: ignoring attributes on template argument ‘Eigen::internal::packet_traits<double>::type’ {aka ‘__vector(2) double’} [-Wignored-attributes]
g++: fatal error: Killed signal terminated program cc1plus
compilation terminated.
make: *** [/opt/R/4.3.1/lib/R/etc/Makeconf:198: stanExports_dfa.o] Error 1
ERROR: compilation failed for package ‘bayesdfa’
* removing ‘/tmp/workdir/bayesdfa/new/bayesdfa.Rcheck/bayesdfa’


```
### CRAN

```
* installing *source* package ‘bayesdfa’ ...
** package ‘bayesdfa’ successfully unpacked and MD5 sums checked
** using staged installation
** libs
using C++ compiler: ‘g++ (Ubuntu 9.4.0-1ubuntu1~20.04.2) 9.4.0’
using C++17


g++ -std=gnu++17 -I"/opt/R/4.3.1/lib/R/include" -DNDEBUG -I"../inst/include" -I"/opt/R/4.3.1/lib/R/site-library/StanHeaders/include/src" -DBOOST_DISABLE_ASSERTS -DEIGEN_NO_DEBUG -DBOOST_MATH_OVERFLOW_ERROR_POLICY=errno_on_error -DUSE_STANC3 -D_HAS_AUTO_PTR_ETC=0 -I'/opt/R/4.3.1/lib/R/site-library/BH/include' -I'/opt/R/4.3.1/lib/R/site-library/Rcpp/include' -I'/opt/R/4.3.1/lib/R/site-library/RcppEigen/include' -I'/opt/R/4.3.1/lib/R/site-library/RcppParallel/include' -I'/opt/R/4.3.1/lib/R/site-library/rstan/include' -I'/opt/R/4.3.1/lib/R/site-library/StanHeaders/include' -I/usr/local/include    -I'/opt/R/4.3.1/lib/R/site-library/RcppParallel/include' -D_REENTRANT -DSTAN_THREADS   -fpic  -g -O2  -c RcppExports.cpp -o RcppExports.o
In file included from /opt/R/4.3.1/lib/R/site-library/RcppEigen/include/Eigen/Core:397,
...
/opt/R/4.3.1/lib/R/site-library/RcppEigen/include/Eigen/src/Core/ProductEvaluators.h:35:90:   required from ‘Eigen::internal::evaluator<Eigen::Product<Lhs, Rhs, Option> >::evaluator(const XprType&) [with Lhs = Eigen::Product<Eigen::CwiseBinaryOp<Eigen::internal::scalar_product_op<double, double>, const Eigen::CwiseNullaryOp<Eigen::internal::scalar_constant_op<double>, const Eigen::Matrix<double, 1, -1> >, const Eigen::Transpose<Eigen::Matrix<double, -1, 1> > >, Eigen::Matrix<double, -1, -1>, 0>; Rhs = Eigen::Matrix<double, -1, 1>; int Options = 0; Eigen::internal::evaluator<Eigen::Product<Lhs, Rhs, Option> >::XprType = Eigen::Product<Eigen::Product<Eigen::CwiseBinaryOp<Eigen::internal::scalar_product_op<double, double>, const Eigen::CwiseNullaryOp<Eigen::internal::scalar_constant_op<double>, const Eigen::Matrix<double, 1, -1> >, const Eigen::Transpose<Eigen::Matrix<double, -1, 1> > >, Eigen::Matrix<double, -1, -1>, 0>, Eigen::Matrix<double, -1, 1>, 0>]’
/opt/R/4.3.1/lib/R/site-library/RcppEigen/include/Eigen/src/Core/Product.h:132:22:   required from ‘Eigen::internal::dense_product_base<Lhs, Rhs, Option, 6>::operator const Scalar() const [with Lhs = Eigen::Product<Eigen::CwiseBinaryOp<Eigen::internal::scalar_product_op<double, double>, const Eigen::CwiseNullaryOp<Eigen::internal::scalar_constant_op<double>, const Eigen::Matrix<double, 1, -1> >, const Eigen::Transpose<Eigen::Matrix<double, -1, 1> > >, Eigen::Matrix<double, -1, -1>, 0>; Rhs = Eigen::Matrix<double, -1, 1>; int Option = 0; Eigen::internal::dense_product_base<Lhs, Rhs, Option, 6>::Scalar = double]’
/opt/R/4.3.1/lib/R/site-library/StanHeaders/include/src/stan/mcmc/hmc/hamiltonians/dense_e_metric.hpp:22:56:   required from ‘double stan::mcmc::dense_e_metric<Model, BaseRNG>::T(stan::mcmc::dense_e_point&) [with Model = model_dfa_namespace::model_dfa; BaseRNG = boost::random::additive_combine_engine<boost::random::linear_congruential_engine<unsigned int, 40014, 0, 2147483563>, boost::random::linear_congruential_engine<unsigned int, 40692, 0, 2147483399> >]’
/opt/R/4.3.1/lib/R/site-library/StanHeaders/include/src/stan/mcmc/hmc/hamiltonians/dense_e_metric.hpp:21:10:   required from here
/opt/R/4.3.1/lib/R/site-library/RcppEigen/include/Eigen/src/Core/DenseCoeffsBase.h:55:30: warning: ignoring attributes on template argument ‘Eigen::internal::packet_traits<double>::type’ {aka ‘__vector(2) double’} [-Wignored-attributes]
g++: fatal error: Killed signal terminated program cc1plus
compilation terminated.
make: *** [/opt/R/4.3.1/lib/R/etc/Makeconf:198: stanExports_dfa.o] Error 1
ERROR: compilation failed for package ‘bayesdfa’
* removing ‘/tmp/workdir/bayesdfa/old/bayesdfa.Rcheck/bayesdfa’


```
# benchmarkfdrData2019

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/benchmarkfdrData2019
* Number of recursive dependencies: 142

Run `revdepcheck::cloud_details(, "benchmarkfdrData2019")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# BindingSiteFinder

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/BindingSiteFinder
* Number of recursive dependencies: 213

Run `revdepcheck::cloud_details(, "BindingSiteFinder")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# BiocBook

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/BiocBook
* Number of recursive dependencies: 92

Run `revdepcheck::cloud_details(, "BiocBook")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# BiocPkgTools

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/BiocPkgTools
* Number of recursive dependencies: 164

Run `revdepcheck::cloud_details(, "BiocPkgTools")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# BiocSet

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/BiocSet
* Number of recursive dependencies: 137

Run `revdepcheck::cloud_details(, "BiocSet")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# biocthis

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/biocthis
* Number of recursive dependencies: 114

Run `revdepcheck::cloud_details(, "biocthis")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# BioNERO

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/BioNERO
* Number of recursive dependencies: 179

Run `revdepcheck::cloud_details(, "BioNERO")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# biovizBase

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/biovizBase
* Number of recursive dependencies: 142

Run `revdepcheck::cloud_details(, "biovizBase")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# biscuiteer

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/biscuiteer
* Number of recursive dependencies: 223

Run `revdepcheck::cloud_details(, "biscuiteer")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# brendaDb

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/brendaDb
* Number of recursive dependencies: 120

Run `revdepcheck::cloud_details(, "brendaDb")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# brolgar

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/brolgar
* Number of recursive dependencies: 117

Run `revdepcheck::cloud_details(, "brolgar")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cageminer

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/cageminer
* Number of recursive dependencies: 214

Run `revdepcheck::cloud_details(, "cageminer")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CBEA

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CBEA
* Number of recursive dependencies: 236

Run `revdepcheck::cloud_details(, "CBEA")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CBNplot

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CBNplot
* Number of recursive dependencies: 251

Run `revdepcheck::cloud_details(, "CBNplot")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cbpManager

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/cbpManager
* Number of recursive dependencies: 97

Run `revdepcheck::cloud_details(, "cbpManager")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# celaref

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/celaref
* Number of recursive dependencies: 139

Run `revdepcheck::cloud_details(, "celaref")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CellaRepertorium

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CellaRepertorium
* Number of recursive dependencies: 172

Run `revdepcheck::cloud_details(, "CellaRepertorium")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CellBench

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CellBench
* Number of recursive dependencies: 125

Run `revdepcheck::cloud_details(, "CellBench")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# censcyt

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/censcyt
* Number of recursive dependencies: 195

Run `revdepcheck::cloud_details(, "censcyt")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# Cepo

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/Cepo
* Number of recursive dependencies: 227

Run `revdepcheck::cloud_details(, "Cepo")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ceRNAnetsim

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ceRNAnetsim
* Number of recursive dependencies: 102

Run `revdepcheck::cloud_details(, "ceRNAnetsim")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cfdnakit

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/cfdnakit
* Number of recursive dependencies: 116

Run `revdepcheck::cloud_details(, "cfdnakit")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cfDNAPro

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/cfDNAPro
* Number of recursive dependencies: 187

Run `revdepcheck::cloud_details(, "cfDNAPro")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# circRNAprofiler

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/circRNAprofiler
* Number of recursive dependencies: 228

Run `revdepcheck::cloud_details(, "circRNAprofiler")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CircSeqAlignTk

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CircSeqAlignTk
* Number of recursive dependencies: 149

Run `revdepcheck::cloud_details(, "CircSeqAlignTk")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CiteFuse

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CiteFuse
* Number of recursive dependencies: 184

Run `revdepcheck::cloud_details(, "CiteFuse")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ClassifyR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ClassifyR
* Number of recursive dependencies: 189

Run `revdepcheck::cloud_details(, "ClassifyR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# clusterProfiler

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/clusterProfiler
* Number of recursive dependencies: 175

Run `revdepcheck::cloud_details(, "clusterProfiler")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# clustifyr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/clustifyr
* Number of recursive dependencies: 200

Run `revdepcheck::cloud_details(, "clustifyr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cogeqc

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/cogeqc
* Number of recursive dependencies: 112

Run `revdepcheck::cloud_details(, "cogeqc")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# comapr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/comapr
* Number of recursive dependencies: 174

Run `revdepcheck::cloud_details(, "comapr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# COMPASS

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/COMPASS
* Number of recursive dependencies: 154

Run `revdepcheck::cloud_details(, "COMPASS")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ComPrAn

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ComPrAn
* Number of recursive dependencies: 113

Run `revdepcheck::cloud_details(, "ComPrAn")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# concordexR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/concordexR
* Number of recursive dependencies: 182

Run `revdepcheck::cloud_details(, "concordexR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CoreGx

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CoreGx
* Number of recursive dependencies: 145

Run `revdepcheck::cloud_details(, "CoreGx")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cosmosR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/cosmosR
* Number of recursive dependencies: 156

Run `revdepcheck::cloud_details(, "cosmosR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# COTAN

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/COTAN
* Number of recursive dependencies: 268

Run `revdepcheck::cloud_details(, "COTAN")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# crisprVerse

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/crisprVerse
* Number of recursive dependencies: 193

Run `revdepcheck::cloud_details(, "crisprVerse")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cTRAP

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/cTRAP
* Number of recursive dependencies: 173

Run `revdepcheck::cloud_details(, "cTRAP")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CuratedAtlasQueryR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CuratedAtlasQueryR
* Number of recursive dependencies: 193

Run `revdepcheck::cloud_details(, "CuratedAtlasQueryR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# curatedMetagenomicData

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/curatedMetagenomicData
* Number of recursive dependencies: 193

Run `revdepcheck::cloud_details(, "curatedMetagenomicData")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# curatedTBData

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/curatedTBData
* Number of recursive dependencies: 137

Run `revdepcheck::cloud_details(, "curatedTBData")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CyTOFpower

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CyTOFpower
* Number of recursive dependencies: 231

Run `revdepcheck::cloud_details(, "CyTOFpower")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CytoGLMM

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CytoGLMM
* Number of recursive dependencies: 176

Run `revdepcheck::cloud_details(, "CytoGLMM")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cytoKernel

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/cytoKernel
* Number of recursive dependencies: 111

Run `revdepcheck::cloud_details(, "cytoKernel")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# CytoPipeline

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/CytoPipeline
* Number of recursive dependencies: 148

Run `revdepcheck::cloud_details(, "CytoPipeline")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# dce

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/dce
* Number of recursive dependencies: 324

Run `revdepcheck::cloud_details(, "dce")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# dearseq

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/dearseq
* Number of recursive dependencies: 156

Run `revdepcheck::cloud_details(, "dearseq")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# decoupleR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/decoupleR
* Number of recursive dependencies: 255

Run `revdepcheck::cloud_details(, "decoupleR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# DEGreport

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/DEGreport
* Number of recursive dependencies: 148

Run `revdepcheck::cloud_details(, "DEGreport")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# DIAlignR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/DIAlignR
* Number of recursive dependencies: 119

Run `revdepcheck::cloud_details(, "DIAlignR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# dStruct

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/dStruct
* Number of recursive dependencies: 126

Run `revdepcheck::cloud_details(, "dStruct")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# easier

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/easier
* Number of recursive dependencies: 198

Run `revdepcheck::cloud_details(, "easier")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# easyalluvial

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/easyalluvial
* Number of recursive dependencies: 152

Run `revdepcheck::cloud_details(, "easyalluvial")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# easyreporting

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/easyreporting
* Number of recursive dependencies: 145

Run `revdepcheck::cloud_details(, "easyreporting")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# enrichplot

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/enrichplot
* Number of recursive dependencies: 167

Run `revdepcheck::cloud_details(, "enrichplot")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# EpiMix

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/EpiMix
* Number of recursive dependencies: 313

Run `revdepcheck::cloud_details(, "EpiMix")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# escape

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/escape
* Number of recursive dependencies: 213

Run `revdepcheck::cloud_details(, "escape")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# escheR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/escheR
* Number of recursive dependencies: 249

Run `revdepcheck::cloud_details(, "escheR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# evaluator

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/evaluator
* Number of recursive dependencies: 172

Run `revdepcheck::cloud_details(, "evaluator")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# extraChIPs

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/extraChIPs
* Number of recursive dependencies: 257

Run `revdepcheck::cloud_details(, "extraChIPs")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# factR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/factR
* Number of recursive dependencies: 198

Run `revdepcheck::cloud_details(, "factR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# fenr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/fenr
* Number of recursive dependencies: 128

Run `revdepcheck::cloud_details(, "fenr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# FindIT2

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/FindIT2
* Number of recursive dependencies: 149

Run `revdepcheck::cloud_details(, "FindIT2")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# flowGate

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/flowGate
* Number of recursive dependencies: 152

Run `revdepcheck::cloud_details(, "flowGate")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# FlowSOM

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/FlowSOM
* Number of recursive dependencies: 154

Run `revdepcheck::cloud_details(, "FlowSOM")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# flowTime

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/flowTime
* Number of recursive dependencies: 124

Run `revdepcheck::cloud_details(, "flowTime")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# gemma.R

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/gemma.R
* Number of recursive dependencies: 117

Run `revdepcheck::cloud_details(, "gemma.R")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# genekitr

<details>

* Version: 1.2.5
* GitHub: https://github.com/GangLiLab/genekitr
* Source code: https://github.com/cran/genekitr
* Date/Publication: 2023-09-07 08:50:09 UTC
* Number of recursive dependencies: 222

Run `revdepcheck::cloud_details(, "genekitr")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/genekitr/new/genekitr.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘genekitr/DESCRIPTION’ ... OK
...
* this is package ‘genekitr’ version ‘1.2.5’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Package required but not available: ‘clusterProfiler’

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
### CRAN

```
* using log directory ‘/tmp/workdir/genekitr/old/genekitr.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘genekitr/DESCRIPTION’ ... OK
...
* this is package ‘genekitr’ version ‘1.2.5’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Package required but not available: ‘clusterProfiler’

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
# GeneTonic

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/GeneTonic
* Number of recursive dependencies: 214

Run `revdepcheck::cloud_details(, "GeneTonic")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# GenomicDataCommons

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/GenomicDataCommons
* Number of recursive dependencies: 160

Run `revdepcheck::cloud_details(, "GenomicDataCommons")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# GeomxTools

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/GeomxTools
* Number of recursive dependencies: 215

Run `revdepcheck::cloud_details(, "GeomxTools")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# gg4way

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/gg4way
* Number of recursive dependencies: 132

Run `revdepcheck::cloud_details(, "gg4way")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ggbio

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ggbio
* Number of recursive dependencies: 177

Run `revdepcheck::cloud_details(, "ggbio")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ggcyto

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ggcyto
* Number of recursive dependencies: 141

Run `revdepcheck::cloud_details(, "ggcyto")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ggmanh

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ggmanh
* Number of recursive dependencies: 87

Run `revdepcheck::cloud_details(, "ggmanh")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ggsc

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ggsc
* Number of recursive dependencies: 254

Run `revdepcheck::cloud_details(, "ggsc")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ggtree

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ggtree
* Number of recursive dependencies: 94

Run `revdepcheck::cloud_details(, "ggtree")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ggtreeExtra

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ggtreeExtra
* Number of recursive dependencies: 91

Run `revdepcheck::cloud_details(, "ggtreeExtra")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# glmGamPoi

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/glmGamPoi
* Number of recursive dependencies: 169

Run `revdepcheck::cloud_details(, "glmGamPoi")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# GloScope

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/GloScope
* Number of recursive dependencies: 113

Run `revdepcheck::cloud_details(, "GloScope")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# GOSemSim

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/GOSemSim
* Number of recursive dependencies: 174

Run `revdepcheck::cloud_details(, "GOSemSim")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# grandR

<details>

* Version: 0.2.2
* GitHub: https://github.com/erhard-lab/grandR
* Source code: https://github.com/cran/grandR
* Date/Publication: 2023-04-20 21:22:30 UTC
* Number of recursive dependencies: 267

Run `revdepcheck::cloud_details(, "grandR")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/grandR/new/grandR.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘grandR/DESCRIPTION’ ... OK
...
* checking installed files from ‘inst/doc’ ... OK
* checking files in ‘vignettes’ ... OK
* checking examples ... OK
* checking for unstated dependencies in vignettes ... OK
* checking package vignettes in ‘inst/doc’ ... OK
* checking running R code from vignettes ... NONE
  ‘getting-started.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 2 NOTEs





```
### CRAN

```
* using log directory ‘/tmp/workdir/grandR/old/grandR.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘grandR/DESCRIPTION’ ... OK
...
* checking installed files from ‘inst/doc’ ... OK
* checking files in ‘vignettes’ ... OK
* checking examples ... OK
* checking for unstated dependencies in vignettes ... OK
* checking package vignettes in ‘inst/doc’ ... OK
* checking running R code from vignettes ... NONE
  ‘getting-started.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 2 NOTEs





```
# GRaNIE

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/GRaNIE
* Number of recursive dependencies: 311

Run `revdepcheck::cloud_details(, "GRaNIE")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# granulator

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/granulator
* Number of recursive dependencies: 134

Run `revdepcheck::cloud_details(, "granulator")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# graphite

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/graphite
* Number of recursive dependencies: 167

Run `revdepcheck::cloud_details(, "graphite")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# GSEAmining

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/GSEAmining
* Number of recursive dependencies: 183

Run `revdepcheck::cloud_details(, "GSEAmining")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# GUIDEseq

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/GUIDEseq
* Number of recursive dependencies: 197

Run `revdepcheck::cloud_details(, "GUIDEseq")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# HCAExplorer

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/HCAExplorer
* Number of recursive dependencies: 114

Run `revdepcheck::cloud_details(, "HCAExplorer")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# hermes

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/hermes
* Number of recursive dependencies: 164

Run `revdepcheck::cloud_details(, "hermes")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# HiCDCPlus

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/HiCDCPlus
* Number of recursive dependencies: 166

Run `revdepcheck::cloud_details(, "HiCDCPlus")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# HIPPO

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/HIPPO
* Number of recursive dependencies: 93

Run `revdepcheck::cloud_details(, "HIPPO")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# hoodscanR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/hoodscanR
* Number of recursive dependencies: 127

Run `revdepcheck::cloud_details(, "hoodscanR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# hypeR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/hypeR
* Number of recursive dependencies: 166

Run `revdepcheck::cloud_details(, "hypeR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# iCNV

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/iCNV
* Number of recursive dependencies: 105

Run `revdepcheck::cloud_details(, "iCNV")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ideal

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ideal
* Number of recursive dependencies: 219

Run `revdepcheck::cloud_details(, "ideal")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# idpr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/idpr
* Number of recursive dependencies: 90

Run `revdepcheck::cloud_details(, "idpr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# immcp

<details>

* Version: 1.0.3
* GitHub: https://github.com/YuanlongHu/immcp
* Source code: https://github.com/cran/immcp
* Date/Publication: 2022-05-12 05:50:02 UTC
* Number of recursive dependencies: 211

Run `revdepcheck::cloud_details(, "immcp")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/immcp/new/immcp.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘immcp/DESCRIPTION’ ... OK
...
* this is package ‘immcp’ version ‘1.0.3’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Packages required but not available: 'clusterProfiler', 'DOSE'

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
### CRAN

```
* using log directory ‘/tmp/workdir/immcp/old/immcp.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘immcp/DESCRIPTION’ ... OK
...
* this is package ‘immcp’ version ‘1.0.3’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Packages required but not available: 'clusterProfiler', 'DOSE'

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
# immunotation

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/immunotation
* Number of recursive dependencies: 103

Run `revdepcheck::cloud_details(, "immunotation")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# InterCellar

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/InterCellar
* Number of recursive dependencies: 203

Run `revdepcheck::cloud_details(, "InterCellar")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# IntOMICS

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/IntOMICS
* Number of recursive dependencies: 225

Run `revdepcheck::cloud_details(, "IntOMICS")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ISAnalytics

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ISAnalytics
* Number of recursive dependencies: 173

Run `revdepcheck::cloud_details(, "ISAnalytics")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# isomiRs

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/isomiRs
* Number of recursive dependencies: 166

Run `revdepcheck::cloud_details(, "isomiRs")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# isoreader

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/isoreader
* Number of recursive dependencies: 131

Run `revdepcheck::cloud_details(, "isoreader")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# jsontools

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/jsontools
* Number of recursive dependencies: 65

Run `revdepcheck::cloud_details(, "jsontools")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# katdetectr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/katdetectr
* Number of recursive dependencies: 155

Run `revdepcheck::cloud_details(, "katdetectr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ldblock

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ldblock
* Number of recursive dependencies: 137

Run `revdepcheck::cloud_details(, "ldblock")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# lipidr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/lipidr
* Number of recursive dependencies: 141

Run `revdepcheck::cloud_details(, "lipidr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# loon.ggplot

<details>

* Version: 1.3.3
* GitHub: https://github.com/great-northern-diver/loon.ggplot
* Source code: https://github.com/cran/loon.ggplot
* Date/Publication: 2022-11-12 22:30:02 UTC
* Number of recursive dependencies: 106

Run `revdepcheck::cloud_details(, "loon.ggplot")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/loon.ggplot/new/loon.ggplot.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘loon.ggplot/DESCRIPTION’ ... OK
...
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Package required but not available: ‘loon’

Package suggested but not available for checking: ‘zenplots’

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
### CRAN

```
* using log directory ‘/tmp/workdir/loon.ggplot/old/loon.ggplot.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘loon.ggplot/DESCRIPTION’ ... OK
...
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Package required but not available: ‘loon’

Package suggested but not available for checking: ‘zenplots’

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
# mariner

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/mariner
* Number of recursive dependencies: 160

Run `revdepcheck::cloud_details(, "mariner")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# marr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/marr
* Number of recursive dependencies: 100

Run `revdepcheck::cloud_details(, "marr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MatrixQCvis

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MatrixQCvis
* Number of recursive dependencies: 185

Run `revdepcheck::cloud_details(, "MatrixQCvis")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# memes

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/memes
* Number of recursive dependencies: 162

Run `revdepcheck::cloud_details(, "memes")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# metabCombiner

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/metabCombiner
* Number of recursive dependencies: 117

Run `revdepcheck::cloud_details(, "metabCombiner")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MetaScope

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MetaScope
* Number of recursive dependencies: 207

Run `revdepcheck::cloud_details(, "MetaScope")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MethReg

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MethReg
* Number of recursive dependencies: 228

Run `revdepcheck::cloud_details(, "MethReg")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MetNet

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MetNet
* Number of recursive dependencies: 128

Run `revdepcheck::cloud_details(, "MetNet")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# mia

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/mia
* Number of recursive dependencies: 223

Run `revdepcheck::cloud_details(, "mia")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# miaViz

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/miaViz
* Number of recursive dependencies: 202

Run `revdepcheck::cloud_details(, "miaViz")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# microbiomeExplorer

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/microbiomeExplorer
* Number of recursive dependencies: 188

Run `revdepcheck::cloud_details(, "microbiomeExplorer")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# microbiomeMarker

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/microbiomeMarker
* Number of recursive dependencies: 309

Run `revdepcheck::cloud_details(, "microbiomeMarker")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MicrobiotaProcess

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MicrobiotaProcess
* Number of recursive dependencies: 195

Run `revdepcheck::cloud_details(, "MicrobiotaProcess")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# microSTASIS

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/microSTASIS
* Number of recursive dependencies: 127

Run `revdepcheck::cloud_details(, "microSTASIS")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# midasHLA

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/midasHLA
* Number of recursive dependencies: 208

Run `revdepcheck::cloud_details(, "midasHLA")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# mistyR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/mistyR
* Number of recursive dependencies: 156

Run `revdepcheck::cloud_details(, "mistyR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MoleculeExperiment

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MoleculeExperiment
* Number of recursive dependencies: 133

Run `revdepcheck::cloud_details(, "MoleculeExperiment")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MOMA

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MOMA
* Number of recursive dependencies: 147

Run `revdepcheck::cloud_details(, "MOMA")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MOSim

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MOSim
* Number of recursive dependencies: 84

Run `revdepcheck::cloud_details(, "MOSim")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MQmetrics

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MQmetrics
* Number of recursive dependencies: 118

Run `revdepcheck::cloud_details(, "MQmetrics")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MSA2dist

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MSA2dist
* Number of recursive dependencies: 141

Run `revdepcheck::cloud_details(, "MSA2dist")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MSnID

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MSnID
* Number of recursive dependencies: 152

Run `revdepcheck::cloud_details(, "MSnID")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MSPrep

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MSPrep
* Number of recursive dependencies: 163

Run `revdepcheck::cloud_details(, "MSPrep")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# multiGSEA

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/multiGSEA
* Number of recursive dependencies: 168

Run `revdepcheck::cloud_details(, "multiGSEA")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MultiRNAflow

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MultiRNAflow
* Number of recursive dependencies: 185

Run `revdepcheck::cloud_details(, "MultiRNAflow")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# musicatk

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/musicatk
* Number of recursive dependencies: 284

Run `revdepcheck::cloud_details(, "musicatk")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# NanoMethViz

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/NanoMethViz
* Number of recursive dependencies: 192

Run `revdepcheck::cloud_details(, "NanoMethViz")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# NanoporeRNASeq

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/NanoporeRNASeq
* Number of recursive dependencies: 185

Run `revdepcheck::cloud_details(, "NanoporeRNASeq")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# nanotatoR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/nanotatoR
* Number of recursive dependencies: 144

Run `revdepcheck::cloud_details(, "nanotatoR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# NanoTube

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/NanoTube
* Number of recursive dependencies: 180

Run `revdepcheck::cloud_details(, "NanoTube")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# nearBynding

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/nearBynding
* Number of recursive dependencies: 131

Run `revdepcheck::cloud_details(, "nearBynding")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ngsReports

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ngsReports
* Number of recursive dependencies: 122

Run `revdepcheck::cloud_details(, "ngsReports")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# nipalsMCIA

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/nipalsMCIA
* Number of recursive dependencies: 255

Run `revdepcheck::cloud_details(, "nipalsMCIA")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# NPARC

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/NPARC
* Number of recursive dependencies: 128

Run `revdepcheck::cloud_details(, "NPARC")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# nullranges

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/nullranges
* Number of recursive dependencies: 195

Run `revdepcheck::cloud_details(, "nullranges")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# OlinkAnalyze

<details>

* Version: 3.5.1
* GitHub: NA
* Source code: https://github.com/cran/OlinkAnalyze
* Date/Publication: 2023-08-08 21:00:02 UTC
* Number of recursive dependencies: 230

Run `revdepcheck::cloud_details(, "OlinkAnalyze")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/OlinkAnalyze/new/OlinkAnalyze.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘OlinkAnalyze/DESCRIPTION’ ... OK
...
* checking for unstated dependencies in vignettes ... OK
* checking package vignettes in ‘inst/doc’ ... OK
* checking running R code from vignettes ... NONE
  ‘OutlierExclusion.Rmd’ using ‘UTF-8’... OK
  ‘Vignett.Rmd’ using ‘UTF-8’... OK
  ‘bridging_introduction.Rmd’ using ‘UTF-8’... OK
  ‘plate_randomizer.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 1 NOTE





```
### CRAN

```
* using log directory ‘/tmp/workdir/OlinkAnalyze/old/OlinkAnalyze.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘OlinkAnalyze/DESCRIPTION’ ... OK
...
* checking for unstated dependencies in vignettes ... OK
* checking package vignettes in ‘inst/doc’ ... OK
* checking running R code from vignettes ... NONE
  ‘OutlierExclusion.Rmd’ using ‘UTF-8’... OK
  ‘Vignett.Rmd’ using ‘UTF-8’... OK
  ‘bridging_introduction.Rmd’ using ‘UTF-8’... OK
  ‘plate_randomizer.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 1 NOTE





```
# OmnipathR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/OmnipathR
* Number of recursive dependencies: 164

Run `revdepcheck::cloud_details(, "OmnipathR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# optimalFlow

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/optimalFlow
* Number of recursive dependencies: 93

Run `revdepcheck::cloud_details(, "optimalFlow")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# Organism.dplyr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/Organism.dplyr
* Number of recursive dependencies: 139

Run `revdepcheck::cloud_details(, "Organism.dplyr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# orthos

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/orthos
* Number of recursive dependencies: 181

Run `revdepcheck::cloud_details(, "orthos")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# PanomiR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/PanomiR
* Number of recursive dependencies: 202

Run `revdepcheck::cloud_details(, "PanomiR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# PanViz

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/PanViz
* Number of recursive dependencies: 81

Run `revdepcheck::cloud_details(, "PanViz")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# pareg

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/pareg
* Number of recursive dependencies: 320

Run `revdepcheck::cloud_details(, "pareg")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# PAST

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/PAST
* Number of recursive dependencies: 99

Run `revdepcheck::cloud_details(, "PAST")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# PDATK

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/PDATK
* Number of recursive dependencies: 269

Run `revdepcheck::cloud_details(, "PDATK")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# PhosR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/PhosR
* Number of recursive dependencies: 185

Run `revdepcheck::cloud_details(, "PhosR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# plotgardener

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/plotgardener
* Number of recursive dependencies: 173

Run `revdepcheck::cloud_details(, "plotgardener")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# plotGrouper

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/plotGrouper
* Number of recursive dependencies: 137

Run `revdepcheck::cloud_details(, "plotGrouper")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# plyinteractions

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/plyinteractions
* Number of recursive dependencies: 188

Run `revdepcheck::cloud_details(, "plyinteractions")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# plyranges

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/plyranges
* Number of recursive dependencies: 143

Run `revdepcheck::cloud_details(, "plyranges")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# pmdplyr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/pmdplyr
* Number of recursive dependencies: 121

Run `revdepcheck::cloud_details(, "pmdplyr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ppcseq

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ppcseq
* Number of recursive dependencies: 116

Run `revdepcheck::cloud_details(, "ppcseq")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# proActiv

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/proActiv
* Number of recursive dependencies: 141

Run `revdepcheck::cloud_details(, "proActiv")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# profileplyr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/profileplyr
* Number of recursive dependencies: 229

Run `revdepcheck::cloud_details(, "profileplyr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ProteoDisco

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ProteoDisco
* Number of recursive dependencies: 190

Run `revdepcheck::cloud_details(, "ProteoDisco")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# protGear

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/protGear
* Number of recursive dependencies: 199

Run `revdepcheck::cloud_details(, "protGear")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ptairMS

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ptairMS
* Number of recursive dependencies: 194

Run `revdepcheck::cloud_details(, "ptairMS")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# qckitfastq

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/qckitfastq
* Number of recursive dependencies: 91

Run `revdepcheck::cloud_details(, "qckitfastq")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# qmtools

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/qmtools
* Number of recursive dependencies: 183

Run `revdepcheck::cloud_details(, "qmtools")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# qPLEXanalyzer

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/qPLEXanalyzer
* Number of recursive dependencies: 150

Run `revdepcheck::cloud_details(, "qPLEXanalyzer")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# QTLExperiment

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/QTLExperiment
* Number of recursive dependencies: 107

Run `revdepcheck::cloud_details(, "QTLExperiment")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# quantiseqr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/quantiseqr
* Number of recursive dependencies: 150

Run `revdepcheck::cloud_details(, "quantiseqr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# RAIDS

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/RAIDS
* Number of recursive dependencies: 183

Run `revdepcheck::cloud_details(, "RAIDS")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# Rcpi

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/Rcpi
* Number of recursive dependencies: 86

Run `revdepcheck::cloud_details(, "Rcpi")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ReactomeGraph4R

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ReactomeGraph4R
* Number of recursive dependencies: 89

Run `revdepcheck::cloud_details(, "ReactomeGraph4R")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# restfulSE

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/restfulSE
* Number of recursive dependencies: 135

Run `revdepcheck::cloud_details(, "restfulSE")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# RiboCrypt

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/RiboCrypt
* Number of recursive dependencies: 173

Run `revdepcheck::cloud_details(, "RiboCrypt")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# ribor

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ribor
* Number of recursive dependencies: 79

Run `revdepcheck::cloud_details(, "ribor")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rifi

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/rifi
* Number of recursive dependencies: 195

Run `revdepcheck::cloud_details(, "rifi")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# rifiComparative

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/rifiComparative
* Number of recursive dependencies: 183

Run `revdepcheck::cloud_details(, "rifiComparative")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# RNAseqCovarImpute

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/RNAseqCovarImpute
* Number of recursive dependencies: 111

Run `revdepcheck::cloud_details(, "RNAseqCovarImpute")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# RVA

<details>

* Version: 0.0.5
* GitHub: https://github.com/THERMOSTATS/RVA
* Source code: https://github.com/cran/RVA
* Date/Publication: 2021-11-01 21:40:02 UTC
* Number of recursive dependencies: 227

Run `revdepcheck::cloud_details(, "RVA")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/RVA/new/RVA.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘RVA/DESCRIPTION’ ... OK
...
* this is package ‘RVA’ version ‘0.0.5’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Package required but not available: ‘clusterProfiler’

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
### CRAN

```
* using log directory ‘/tmp/workdir/RVA/old/RVA.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘RVA/DESCRIPTION’ ... OK
...
* this is package ‘RVA’ version ‘0.0.5’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Package required but not available: ‘clusterProfiler’

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR





```
# scater

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/scater
* Number of recursive dependencies: 198

Run `revdepcheck::cloud_details(, "scater")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# sccomp

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/sccomp
* Number of recursive dependencies: 196

Run `revdepcheck::cloud_details(, "sccomp")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# scFeatureFilter

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/scFeatureFilter
* Number of recursive dependencies: 155

Run `revdepcheck::cloud_details(, "scFeatureFilter")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# scider

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/scider
* Number of recursive dependencies: 153

Run `revdepcheck::cloud_details(, "scider")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# scifer

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/scifer
* Number of recursive dependencies: 123

Run `revdepcheck::cloud_details(, "scifer")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# scPipe

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/scPipe
* Number of recursive dependencies: 256

Run `revdepcheck::cloud_details(, "scPipe")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# SCpubr

<details>

* Version: 2.0.2
* GitHub: https://github.com/enblacar/SCpubr
* Source code: https://github.com/cran/SCpubr
* Date/Publication: 2023-10-11 09:50:02 UTC
* Number of recursive dependencies: 315

Run `revdepcheck::cloud_details(, "SCpubr")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/SCpubr/new/SCpubr.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘SCpubr/DESCRIPTION’ ... OK
...
* checking for unstated dependencies in ‘tests’ ... OK
* checking tests ... OK
  Running ‘testthat.R’
* checking for unstated dependencies in vignettes ... OK
* checking package vignettes in ‘inst/doc’ ... OK
* checking running R code from vignettes ... NONE
  ‘reference_manual.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 1 NOTE





```
### CRAN

```
* using log directory ‘/tmp/workdir/SCpubr/old/SCpubr.Rcheck’
* using R version 4.3.1 (2023-06-16)
* using platform: x86_64-pc-linux-gnu (64-bit)
* R was compiled by
    gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
    GNU Fortran (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0
* running under: Ubuntu 20.04.6 LTS
* using session charset: UTF-8
* using option ‘--no-manual’
* checking for file ‘SCpubr/DESCRIPTION’ ... OK
...
* checking for unstated dependencies in ‘tests’ ... OK
* checking tests ... OK
  Running ‘testthat.R’
* checking for unstated dependencies in vignettes ... OK
* checking package vignettes in ‘inst/doc’ ... OK
* checking running R code from vignettes ... NONE
  ‘reference_manual.Rmd’ using ‘UTF-8’... OK
* checking re-building of vignette outputs ... OK
* DONE
Status: 1 NOTE





```
# ScreenR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/ScreenR
* Number of recursive dependencies: 91

Run `revdepcheck::cloud_details(, "ScreenR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# scRepertoire

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/scRepertoire
* Number of recursive dependencies: 210

Run `revdepcheck::cloud_details(, "scRepertoire")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# seqCAT

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/seqCAT
* Number of recursive dependencies: 135

Run `revdepcheck::cloud_details(, "seqCAT")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# shinyepico

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/shinyepico
* Number of recursive dependencies: 252

Run `revdepcheck::cloud_details(, "shinyepico")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# single

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/single
* Number of recursive dependencies: 82

Run `revdepcheck::cloud_details(, "single")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# singleCellTK

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/singleCellTK
* Number of recursive dependencies: 392

Run `revdepcheck::cloud_details(, "singleCellTK")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# snapcount

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/snapcount
* Number of recursive dependencies: 134

Run `revdepcheck::cloud_details(, "snapcount")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# SpatialCPie

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/SpatialCPie
* Number of recursive dependencies: 129

Run `revdepcheck::cloud_details(, "SpatialCPie")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# SpatialFeatureExperiment

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/SpatialFeatureExperiment
* Number of recursive dependencies: 171

Run `revdepcheck::cloud_details(, "SpatialFeatureExperiment")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# SPIAT

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/SPIAT
* Number of recursive dependencies: 185

Run `revdepcheck::cloud_details(, "SPIAT")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# spicyR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/spicyR
* Number of recursive dependencies: 246

Run `revdepcheck::cloud_details(, "spicyR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# splatter

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/splatter
* Number of recursive dependencies: 255

Run `revdepcheck::cloud_details(, "splatter")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# SpotClean

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/SpotClean
* Number of recursive dependencies: 199

Run `revdepcheck::cloud_details(, "SpotClean")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# sSNAPPY

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/sSNAPPY
* Number of recursive dependencies: 180

Run `revdepcheck::cloud_details(, "sSNAPPY")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# standR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/standR
* Number of recursive dependencies: 232

Run `revdepcheck::cloud_details(, "standR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# StructuralVariantAnnotation

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/StructuralVariantAnnotation
* Number of recursive dependencies: 221

Run `revdepcheck::cloud_details(, "StructuralVariantAnnotation")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# SummarizedBenchmark

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/SummarizedBenchmark
* Number of recursive dependencies: 222

Run `revdepcheck::cloud_details(, "SummarizedBenchmark")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# supersigs

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/supersigs
* Number of recursive dependencies: 176

Run `revdepcheck::cloud_details(, "supersigs")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# svaNUMT

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/svaNUMT
* Number of recursive dependencies: 179

Run `revdepcheck::cloud_details(, "svaNUMT")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# svaRetro

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/svaRetro
* Number of recursive dependencies: 179

Run `revdepcheck::cloud_details(, "svaRetro")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# syntenet

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/syntenet
* Number of recursive dependencies: 145

Run `revdepcheck::cloud_details(, "syntenet")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# systemPipeShiny

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/systemPipeShiny
* Number of recursive dependencies: 200

Run `revdepcheck::cloud_details(, "systemPipeShiny")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# tadar

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/tadar
* Number of recursive dependencies: 193

Run `revdepcheck::cloud_details(, "tadar")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# TBSignatureProfiler

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/TBSignatureProfiler
* Number of recursive dependencies: 227

Run `revdepcheck::cloud_details(, "TBSignatureProfiler")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# tidybulk

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/tidybulk
* Number of recursive dependencies: 350

Run `revdepcheck::cloud_details(, "tidybulk")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# tidySingleCellExperiment

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/tidySingleCellExperiment
* Number of recursive dependencies: 213

Run `revdepcheck::cloud_details(, "tidySingleCellExperiment")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# tidySummarizedExperiment

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/tidySummarizedExperiment
* Number of recursive dependencies: 110

Run `revdepcheck::cloud_details(, "tidySummarizedExperiment")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# treeio

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/treeio
* Number of recursive dependencies: 106

Run `revdepcheck::cloud_details(, "treeio")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# TreeSummarizedExperiment

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/TreeSummarizedExperiment
* Number of recursive dependencies: 116

Run `revdepcheck::cloud_details(, "TreeSummarizedExperiment")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# triptych

<details>

* Version: 0.1.2
* GitHub: https://github.com/aijordan/triptych
* Source code: https://github.com/cran/triptych
* Date/Publication: 2023-10-03 16:30:02 UTC
* Number of recursive dependencies: 66

Run `revdepcheck::cloud_details(, "triptych")` for more info

</details>

## In both

*   checking whether package ‘triptych’ can be installed ... ERROR
    ```
    Installation failed.
    See ‘/tmp/workdir/triptych/new/triptych.Rcheck/00install.out’ for details.
    ```

## Installation

### Devel

```
* installing *source* package ‘triptych’ ...
** package ‘triptych’ successfully unpacked and MD5 sums checked
** using staged installation
** libs
Error: C++20 standard requested but CXX20 is not defined
* removing ‘/tmp/workdir/triptych/new/triptych.Rcheck/triptych’


```
### CRAN

```
* installing *source* package ‘triptych’ ...
** package ‘triptych’ successfully unpacked and MD5 sums checked
** using staged installation
** libs
Error: C++20 standard requested but CXX20 is not defined
* removing ‘/tmp/workdir/triptych/old/triptych.Rcheck/triptych’


```
# tuberculosis

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/tuberculosis
* Number of recursive dependencies: 187

Run `revdepcheck::cloud_details(, "tuberculosis")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# UMI4Cats

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/UMI4Cats
* Number of recursive dependencies: 178

Run `revdepcheck::cloud_details(, "UMI4Cats")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# universalmotif

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/universalmotif
* Number of recursive dependencies: 206

Run `revdepcheck::cloud_details(, "universalmotif")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# variancePartition

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/variancePartition
* Number of recursive dependencies: 209

Run `revdepcheck::cloud_details(, "variancePartition")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# Voyager

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/Voyager
* Number of recursive dependencies: 249

Run `revdepcheck::cloud_details(, "Voyager")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# weitrix

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/weitrix
* Number of recursive dependencies: 197

Run `revdepcheck::cloud_details(, "weitrix")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# wpm

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/wpm
* Number of recursive dependencies: 144

Run `revdepcheck::cloud_details(, "wpm")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# wppi

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/wppi
* Number of recursive dependencies: 88

Run `revdepcheck::cloud_details(, "wppi")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
