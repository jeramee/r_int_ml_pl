## revdepcheck results

We checked 2412 reverse dependencies (2184 from CRAN + 228 from Bioconductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 1 new problems
 * We failed to check 9 packages

Issues with CRAN packages are summarised below.

### New problems
(This reports the first line of each new failure)

* eiCompare
  checking tests ... ERROR
  checking re-building of vignette outputs ... ERROR

### Failed to check

* bayesdfa     (NA)
* genekitr     (NA)
* grandR       (NA)
* immcp        (NA)
* loon.ggplot  (NA)
* OlinkAnalyze (NA)
* RVA          (NA)
* SCpubr       (NA)
* triptych     (NA)
